# 載入需要的套件
from selenium import webdriver
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time
import pandas as pd

def text_pose(text):
	driver.find_element(By.XPATH, '//*[@id="desktop"]').send_keys(text) 

	time.sleep(5)

	driver.find_element(By.XPATH, '//*[@id="desktop"]').clear()

	time.sleep(10)

text = 'I am fine'

driver = webdriver.Chrome()
driver.get("https://sign.mt/")
time.sleep(2)

driver.find_element(By.XPATH, '//*[@id="desktop"]').send_keys(text)

time.sleep(20)

# text = input('please enter a sentence: ')

# while text == '':
# 	time.sleep(10)
# 	text = input('please enter a sentence: ')

# else:
# 	text_pose(text)
# 	text = input('please enter a sentence: ')